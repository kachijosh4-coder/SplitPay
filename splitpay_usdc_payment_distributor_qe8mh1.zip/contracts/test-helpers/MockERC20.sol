// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

/// @dev Minimal ERC-20 mock used only by Foundry tests.
///      Features:
///        - mint() for seeding balances
///        - rejectRecipient: if set, transfer() to that address returns false
///        - returnFalseOnTransferFrom: if true, transferFrom() returns false
contract MockERC20 {
    string  public name;
    string  public symbol;
    uint8   public decimals;
    uint256 public totalSupply;

    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;

    // ── Revert-injection controls ────────────────────────────────────────────
    address public rejectRecipient;          // transfer() returns false for this addr
    bool    public returnFalseOnTransferFrom; // transferFrom() returns false

    event Transfer(address indexed from, address indexed to, uint256 value);
    event Approval(address indexed owner, address indexed spender, uint256 value);

    constructor(string memory _name, string memory _symbol, uint8 _decimals) {
        name     = _name;
        symbol   = _symbol;
        decimals = _decimals;
    }

    // ── Test helpers ─────────────────────────────────────────────────────────

    function mint(address to, uint256 amount) external {
        balanceOf[to] += amount;
        totalSupply   += amount;
        emit Transfer(address(0), to, amount);
    }

    function setRejectRecipient(address recipient) external {
        rejectRecipient = recipient;
    }

    function setReturnFalseOnTransferFrom(bool flag) external {
        returnFalseOnTransferFrom = flag;
    }

    // ── ERC-20 core ──────────────────────────────────────────────────────────

    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        if (to == rejectRecipient) return false;
        require(balanceOf[msg.sender] >= amount, "MockERC20: insufficient");
        balanceOf[msg.sender] -= amount;
        balanceOf[to]         += amount;
        emit Transfer(msg.sender, to, amount);
        return true;
    }

    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        if (returnFalseOnTransferFrom) return false;
        require(balanceOf[from] >= amount, "MockERC20: insufficient");
        require(allowance[from][msg.sender] >= amount, "MockERC20: allowance");
        allowance[from][msg.sender] -= amount;
        balanceOf[from]             -= amount;
        balanceOf[to]               += amount;
        emit Transfer(from, to, amount);
        return true;
    }
}
