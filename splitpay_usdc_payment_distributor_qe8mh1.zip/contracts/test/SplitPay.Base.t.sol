// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {Test} from "forge-std/Test.sol";
import {SplitPay}   from "../SplitPay.sol";
import {MockERC20}  from "../test-helpers/MockERC20.sol";

/// @dev Shared state + setUp used by every SplitPay test category.
abstract contract SplitPayTestBase is Test {

    // ── Actors ───────────────────────────────────────────────────────────────
    address internal payer  = makeAddr("payer");
    address internal alice  = makeAddr("alice");
    address internal bob    = makeAddr("bob");
    address internal carol  = makeAddr("carol");
    address internal dave   = makeAddr("dave");
    address internal eve    = makeAddr("eve");

    // ── Contracts ────────────────────────────────────────────────────────────
    SplitPay  internal splitPay;
    MockERC20 internal token;

    // ── Constants ────────────────────────────────────────────────────────────
    uint256 internal constant BPS = 10_000;

    // ── setUp: runs before EVERY test function ───────────────────────────────
    function setUp() public virtual {
        splitPay = new SplitPay();
        token    = new MockERC20("Mock USDC", "mUSDC", 6);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /// Mint `amount` to `payer` and approve splitPay to spend it.
    function _fund(uint256 amount) internal {
        token.mint(payer, amount);
        vm.prank(payer);
        token.approve(address(splitPay), amount);
    }

    /// Build a two-element address array.
    function _addr2(address a, address b)
        internal pure returns (address[] memory arr)
    {
        arr = new address[](2);
        arr[0] = a; arr[1] = b;
    }

    /// Build a two-element uint256 array.
    function _bps2(uint256 a, uint256 b)
        internal pure returns (uint256[] memory arr)
    {
        arr = new uint256[](2);
        arr[0] = a; arr[1] = b;
    }
}
