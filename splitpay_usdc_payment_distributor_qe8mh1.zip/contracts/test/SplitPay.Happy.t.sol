// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {SplitPayTestBase} from "./SplitPay.Base.t.sol";
import {SplitPay}         from "../SplitPay.sol";

contract SplitPayHappyTest is SplitPayTestBase {

    // ── 2-recipient 50/50 split ───────────────────────────────────────────────
    function test_TwoRecipients_EvenSplit() public {
        uint256 total = 1_000e6;  // 1 000 USDC
        _fund(total);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        // alice: (1_000e6 * 5000) / 10000 = 500e6
        assertEq(token.balanceOf(alice), 500e6, "alice balance");
        // bob: last recipient, absorbs remainder = 1_000e6 - 500e6 = 500e6
        assertEq(token.balanceOf(bob),   500e6, "bob balance");
        // payer's balance is now 0
        assertEq(token.balanceOf(payer),      0, "payer balance");
        // contract holds nothing
        assertEq(token.balanceOf(address(splitPay)), 0, "contract balance");
    }

    // ── 3-recipient uneven 3333/3333/3334 split ──────────────────────────────
    function test_ThreeRecipients_UnevenSplit() public {
        uint256 total = 1_000e6;
        _fund(total);

        address[] memory recips = new address[](3);
        recips[0] = alice; recips[1] = bob; recips[2] = carol;

        uint256[] memory bps = new uint256[](3);
        bps[0] = 3_333; bps[1] = 3_333; bps[2] = 3_334;

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        // alice:  (1_000e6 * 3333) / 10000 = 333_300_000
        // bob:    (1_000e6 * 3333) / 10000 = 333_300_000
        // carol:  1_000e6 - 333_300_000 - 333_300_000 = 333_400_000
        uint256 aliceAmt = (total * 3_333) / BPS;
        uint256 bobAmt   = (total * 3_333) / BPS;
        uint256 carolAmt = total - aliceAmt - bobAmt;

        assertEq(token.balanceOf(alice), aliceAmt, "alice");
        assertEq(token.balanceOf(bob),   bobAmt,   "bob");
        assertEq(token.balanceOf(carol), carolAmt, "carol");

        // Full totalAmount distributed — no dust stuck in contract
        assertEq(aliceAmt + bobAmt + carolAmt, total, "sum == total");
        assertEq(token.balanceOf(address(splitPay)), 0, "no dust in contract");
    }

    // ── Single-recipient (10000 bps) ─────────────────────────────────────────
    function test_SingleRecipient_GetsAll() public {
        uint256 total = 500e6;
        _fund(total);

        address[] memory recips = new address[](1);
        recips[0] = alice;
        uint256[] memory bps = new uint256[](1);
        bps[0] = 10_000;

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        assertEq(token.balanceOf(alice), total, "alice gets all");
        assertEq(token.balanceOf(address(splitPay)), 0, "no dust");
    }

    // ── 5-recipient arbitrary BPS summing to 10 000 ──────────────────────────
    function test_FiveRecipients_SumEqualsTotal() public {
        uint256 total = 1_234_567e6;
        _fund(total);

        address[] memory recips = new address[](5);
        recips[0] = alice; recips[1] = bob; recips[2] = carol;
        recips[3] = dave;  recips[4] = eve;

        uint256[] memory bps = new uint256[](5);
        // 1000 + 2000 + 3000 + 2500 + 1500 = 10000
        bps[0] = 1_000; bps[1] = 2_000; bps[2] = 3_000;
        bps[3] = 2_500; bps[4] = 1_500;

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        uint256 sum = token.balanceOf(alice)
                    + token.balanceOf(bob)
                    + token.balanceOf(carol)
                    + token.balanceOf(dave)
                    + token.balanceOf(eve);

        assertEq(sum, total, "sum of balances == totalAmount");
        assertEq(token.balanceOf(address(splitPay)), 0, "no dust stuck");
    }

    // ── Split event emitted with correct fields ───────────────────────────────
    function test_EmitsSplitEvent() public {
        uint256 total = 200e6;
        _fund(total);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(4_000, 6_000);

        uint256 aliceAmt = (total * 4_000) / BPS;       // 80e6
        uint256 bobAmt   = total - aliceAmt;             // 120e6 (last recipient)

        uint256[] memory expectedAmts = new uint256[](2);
        expectedAmts[0] = aliceAmt;
        expectedAmts[1] = bobAmt;

        // expectEmit: check topic1 (indexed initiator), check data fields
        vm.expectEmit(true, false, false, true, address(splitPay));
        emit SplitPay.Split(
            payer,
            address(token),
            total,
            recips,
            expectedAmts
        );

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);
    }

    // ── Verify payer's token balance is debited by exactly totalAmount ────────
    function test_PayerBalanceDebited() public {
        uint256 total      = 300e6;
        uint256 extraMint  = 100e6;
        // mint more than needed to confirm only `total` is pulled
        token.mint(payer, total + extraMint);
        vm.prank(payer);
        token.approve(address(splitPay), total + extraMint);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        assertEq(token.balanceOf(payer), extraMint, "payer loses exactly totalAmount");
    }

    // ── Odd totalAmount: dust goes to last recipient ──────────────────────────
    function test_OddAmount_DustGoesToLastRecipient() public {
        // 3 is odd; with 50/50 bps, (3*5000)/10000 = 1 → distributed=1
        // Last gets 3-1 = 2 (absorbs the dust)
        uint256 total = 3;
        _fund(total);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        assertEq(token.balanceOf(alice), 1, "alice");
        assertEq(token.balanceOf(bob),   2, "bob gets dust");
        assertEq(token.balanceOf(alice) + token.balanceOf(bob), total, "sum");
    }

    // ── Minimum amount (1) with single recipient ──────────────────────────────
    function test_MinAmount_SingleRecipient() public {
        uint256 total = 1;
        _fund(total);

        address[] memory recips = new address[](1);
        recips[0] = alice;
        uint256[] memory bps = new uint256[](1);
        bps[0] = 10_000;

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        assertEq(token.balanceOf(alice), 1, "alice gets 1");
    }
}
