// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {SplitPayTestBase} from "./SplitPay.Base.t.sol";
import {SplitPay}         from "../SplitPay.sol";

contract SplitPayRevertTest is SplitPayTestBase {

    // ── ZeroTokenAddress ─────────────────────────────────────────────────────
    function test_Revert_ZeroTokenAddress() public {
        _fund(100e6);
        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        vm.expectRevert(SplitPay.ZeroTokenAddress.selector);
        splitPay.split(address(0), recips, bps, 100e6);
    }

    // ── ZeroTotalAmount ──────────────────────────────────────────────────────
    function test_Revert_ZeroTotalAmount() public {
        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        vm.expectRevert(SplitPay.ZeroTotalAmount.selector);
        splitPay.split(address(token), recips, bps, 0);
    }

    // ── ArrayLengthMismatch ──────────────────────────────────────────────────
    function test_Revert_ArrayLengthMismatch() public {
        address[] memory recips = _addr2(alice, bob);  // length 2
        uint256[] memory bps    = new uint256[](3);     // length 3
        bps[0] = 3_000; bps[1] = 3_000; bps[2] = 4_000;

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(SplitPay.ArrayLengthMismatch.selector, 2, 3)
        );
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── InvalidRecipientCount: 0 recipients ──────────────────────────────────
    function test_Revert_InvalidRecipientCount_Zero() public {
        address[] memory recips = new address[](0);
        uint256[] memory bps    = new uint256[](0);

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(SplitPay.InvalidRecipientCount.selector, 0)
        );
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── InvalidRecipientCount: 21 recipients ─────────────────────────────────
    function test_Revert_InvalidRecipientCount_TooMany() public {
        uint256 n = 21;
        address[] memory recips = new address[](n);
        uint256[] memory bps    = new uint256[](n);

        // Fill with valid addresses; BPS don't matter — length check fires first
        for (uint256 i = 0; i < n; i++) {
            recips[i] = makeAddr(string(abi.encodePacked("r", i)));
            bps[i]    = 1; // intentionally wrong sum; count check fires first
        }

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(SplitPay.InvalidRecipientCount.selector, n)
        );
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── ZeroRecipient ────────────────────────────────────────────────────────
    function test_Revert_ZeroRecipient() public {
        address[] memory recips = _addr2(alice, address(0));
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(SplitPay.ZeroRecipient.selector, 1)
        );
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── RecipientIsContract (SplitPay itself as recipient) ───────────────────
    function test_Revert_RecipientIsContract() public {
        address[] memory recips = _addr2(alice, address(splitPay));
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(SplitPay.RecipientIsContract.selector, 1)
        );
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── InvalidBasisPointsEntry: bps == 0 ────────────────────────────────────
    function test_Revert_InvalidBasisPointsEntry_Zero() public {
        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(0, 10_000);

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(SplitPay.InvalidBasisPointsEntry.selector, 0, 0)
        );
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── InvalidBasisPointsEntry: bps > 10000 ─────────────────────────────────
    function test_Revert_InvalidBasisPointsEntry_TooLarge() public {
        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(10_001, 1);  // first entry > 10000

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(SplitPay.InvalidBasisPointsEntry.selector, 0, 10_001)
        );
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── BasisPointsSumMustBe10000: sum != 10000 ──────────────────────────────
    function test_Revert_BasisPointsSumMustBe10000() public {
        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(4_999, 5_000); // sum = 9999

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(SplitPay.BasisPointsSumMustBe10000.selector, 9_999)
        );
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── ERC20TransferFromFailed: caller has not approved ─────────────────────
    function test_Revert_TransferFromFailed_NoApproval() public {
        // Mint but do NOT approve — allowance stays 0
        token.mint(payer, 100e6);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        // MockERC20.transferFrom will revert with a string require; but the
        // contract wraps the bool-returning path: set the flag so it returns false.
        // Reset to no-approval path by forcing returnFalse flag.
        token.setReturnFalseOnTransferFrom(true);

        vm.expectRevert(SplitPay.ERC20TransferFromFailed.selector);
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── ERC20TransferFromFailed: insufficient allowance (real path) ───────────
    function test_Revert_TransferFromFailed_InsufficientAllowance() public {
        token.mint(payer, 100e6);
        vm.prank(payer);
        token.approve(address(splitPay), 50e6); // only half

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        // transferFrom will revert with a string require inside the mock.
        // expectRevert with no args catches any revert.
        vm.expectRevert();
        splitPay.split(address(token), recips, bps, 100e6);
    }

    // ── ERC20TransferFailed: transfer to one recipient fails ─────────────────
    function test_Revert_TransferToRecipientFailed() public {
        uint256 total = 100e6;
        _fund(total);

        // Make the mock reject alice
        token.setRejectRecipient(alice);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        uint256 expectedAmt = (total * 5_000) / 10_000; // 50e6

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(
                SplitPay.ERC20TransferFailed.selector,
                0,          // index of alice in the array
                alice,
                expectedAmt
            )
        );
        splitPay.split(address(token), recips, bps, total);
    }

    // ── ERC20TransferFailed: last recipient fails (rejects last addr) ─────────
    function test_Revert_TransferToLastRecipientFailed() public {
        uint256 total = 100e6;
        _fund(total);

        // Make the mock reject bob (last recipient)
        token.setRejectRecipient(bob);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        // bob is last: amount = total - distributed = 100e6 - 50e6 = 50e6
        uint256 aliceAmt = (total * 5_000) / 10_000;
        uint256 bobAmt   = total - aliceAmt;

        vm.prank(payer);
        vm.expectRevert(
            abi.encodeWithSelector(
                SplitPay.ERC20TransferFailed.selector,
                1,      // index of bob
                bob,
                bobAmt
            )
        );
        splitPay.split(address(token), recips, bps, total);
    }
}
