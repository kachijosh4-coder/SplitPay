// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {SplitPayTestBase} from "./SplitPay.Base.t.sol";

/// @dev Fuzz and invariant tests for SplitPay.
///      Invariant: sum of all recipient balances == totalAmount (no dust stuck).
contract SplitPayFuzzTest is SplitPayTestBase {

    // ── Fuzz: 2-recipient 50/50, any totalAmount ─────────────────────────────
    /// @dev Every totalAmount (1 .. type(uint128).max) must distribute fully.
    function testFuzz_TwoRecipients_EvenSplit_SumEqualsTotal(uint128 rawTotal) public {
        // Avoid 0-amount (would revert ZeroTotalAmount by design)
        uint256 total = bound(uint256(rawTotal), 1, type(uint128).max);

        _fund(total);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(5_000, 5_000);

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        uint256 aliceBal = token.balanceOf(alice);
        uint256 bobBal   = token.balanceOf(bob);

        // alice gets floor; bob gets ceiling (absorbs remainder)
        assertEq(aliceBal + bobBal, total, "sum != total");
        // contract holds nothing
        assertEq(token.balanceOf(address(splitPay)), 0, "dust stuck");
    }

    // ── Fuzz: 2 recipients, any totalAmount, random valid BPS ────────────────
    function testFuzz_TwoRecipients_RandomBPS_SumEqualsTotal(
        uint128 rawTotal,
        uint16  rawBps0
    ) public {
        uint256 total = bound(uint256(rawTotal), 1, type(uint128).max);
        // rawBps0 must be in [1, 9999] so bps1 = 10000 - bps0 is in [1, 9999]
        uint256 bps0  = bound(uint256(rawBps0), 1, 9_999);
        uint256 bps1  = 10_000 - bps0;

        _fund(total);

        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(bps0, bps1);

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        assertEq(
            token.balanceOf(alice) + token.balanceOf(bob),
            total,
            "sum != total"
        );
        assertEq(token.balanceOf(address(splitPay)), 0, "dust stuck");
    }

    // ── Fuzz: N recipients (2–10), random BPS summing to 10000 ───────────────
    function testFuzz_NRecipients_RandomBPS_SumEqualsTotal(
        uint8   rawN,
        uint128 rawTotal,
        uint256 seed
    ) public {
        uint256 n     = bound(uint256(rawN), 2, 10);
        uint256 total = bound(uint256(rawTotal), 1, type(uint128).max);

        // Build a valid BPS array that sums to exactly 10 000.
        // Strategy: assign each of the first n-1 recipients a random slice from
        // the remaining budget; last gets the remainder.
        uint256[] memory bps = new uint256[](n);
        uint256 remaining    = 10_000;
        for (uint256 i = 0; i < n - 1; i++) {
            // Max for this slot: remaining - (slots left after this) * 1
            uint256 slotsLeft = n - 1 - i; // slots AFTER current (including last)
            uint256 maxSlice  = remaining - slotsLeft;
            uint256 slice     = bound(
                uint256(keccak256(abi.encode(seed, i))),
                1,
                maxSlice
            );
            bps[i]     = slice;
            remaining -= slice;
        }
        bps[n - 1] = remaining; // last slot absorbs the rest

        // Build recipient addresses
        address[] memory recips = new address[](n);
        for (uint256 i = 0; i < n; i++) {
            recips[i] = makeAddr(string(abi.encodePacked("r", i)));
        }

        _fund(total);

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        uint256 sum;
        for (uint256 i = 0; i < n; i++) {
            sum += token.balanceOf(recips[i]);
        }

        assertEq(sum, total, "sum of balances != totalAmount");
        assertEq(token.balanceOf(address(splitPay)), 0, "dust stuck in contract");
    }

    // ── Fuzz: last recipient always absorbs exact remainder (floor check) ─────
    function testFuzz_LastRecipientAbsorbsRemainder(
        uint128 rawTotal,
        uint16  rawBps0
    ) public {
        uint256 total = bound(uint256(rawTotal), 2, type(uint128).max);
        uint256 bps0  = bound(uint256(rawBps0), 1, 9_999);
        uint256 bps1  = 10_000 - bps0;

        _fund(total);
        address[] memory recips = _addr2(alice, bob);
        uint256[] memory bps    = _bps2(bps0, bps1);

        vm.prank(payer);
        splitPay.split(address(token), recips, bps, total);

        uint256 expectedAlice = (total * bps0) / 10_000;
        uint256 expectedBob   = total - expectedAlice;   // last gets remainder

        assertEq(token.balanceOf(alice), expectedAlice, "alice share");
        assertEq(token.balanceOf(bob),   expectedBob,   "bob remainder");
    }
}
